package model;

import javafx.beans.property.SimpleStringProperty;

public class ProjecaoLine {
	private SimpleStringProperty jogador;
	private SimpleStringProperty atual;
	private SimpleStringProperty nestaRodada;
	private SimpleStringProperty posRodada;
	private SimpleStringProperty projecao1;
	private SimpleStringProperty projecao2;
	private SimpleStringProperty projecao3;
	private SimpleStringProperty projecao4;
	private SimpleStringProperty projecao5;
	private SimpleStringProperty projecao6;
	private SimpleStringProperty projecao7;
	private SimpleStringProperty projecao8;
	private SimpleStringProperty projecao9;
	private SimpleStringProperty projecao10;
	private SimpleStringProperty projecao11;
	private SimpleStringProperty projecao12;
	private SimpleStringProperty projecao13;
	private SimpleStringProperty projecao14;
	private SimpleStringProperty projecao15;
	private SimpleStringProperty projecaoCustom;

	public ProjecaoLine() {
		jogador = new SimpleStringProperty();
		atual = new SimpleStringProperty();
		nestaRodada = new SimpleStringProperty();
		posRodada = new SimpleStringProperty();
		projecao1 = new SimpleStringProperty();
		projecao2 = new SimpleStringProperty();
		projecao3 = new SimpleStringProperty();
		projecao4 = new SimpleStringProperty();
		projecao5 = new SimpleStringProperty();
		projecao6 = new SimpleStringProperty();
		projecao7 = new SimpleStringProperty();
		projecao8 = new SimpleStringProperty();
		projecao9 = new SimpleStringProperty();
		projecao10 = new SimpleStringProperty();
		projecao11 = new SimpleStringProperty();
		projecao12 = new SimpleStringProperty();
		projecao13 = new SimpleStringProperty();
		projecao14 = new SimpleStringProperty();
		projecao15 = new SimpleStringProperty();
		projecaoCustom = new SimpleStringProperty();

	}

	public String getJogador() {
		return jogador.get();
	}
	public void setJogador(String jogador) {
		this.jogador.set(jogador);
	}
	public String getAtual() {
		return atual.get();
	}
	public void setAtual(String atual) {
		this.atual.set(atual);
	}
	public String getNestaRodada() {
		return nestaRodada.get();
	}
	public void setNestaRodada(String nestaRodada) {
		this.nestaRodada.set(nestaRodada);
	}
	public String getPosRodada() {
		return posRodada.get();
	}
	public void setPosRodada(String posRodada) {
		this.posRodada.set(posRodada);
	}
	public String getProjecao1() {
		return projecao1.get();
	}
	public void setProjecao1(String projecao1) {
		this.projecao1.set(projecao1);
	}
	public String getProjecao2() {
		return projecao2.get();
	}
	public void setProjecao2(String projecao2) {
		this.projecao2.set(projecao2);
	}
	public String getProjecao3() {
		return projecao3.get();
	}
	public void setProjecao3(String projecao3) {
		this.projecao3.set(projecao3);
	}
	public String getProjecao4() {
		return projecao4.get();
	}
	public void setProjecao4(String projecao4) {
		this.projecao4.set(projecao4);
	}
	public String getProjecao5() {
		return projecao5.get();
	}
	public void setProjecao5(String projecao5) {
		this.projecao5.set(projecao5);
	}
	public String getProjecao6() {
		return projecao6.get();
	}
	public void setProjecao6(String projecao6) {
		this.projecao6.set(projecao6);
	}
	public String getProjecao7() {
		return projecao7.get();
	}
	public void setProjecao7(String projecao7) {
		this.projecao7.set(projecao7);
	}
	public String getProjecao8() {
		return projecao8.get();
	}
	public void setProjecao8(String projecao8) {
		this.projecao8.set(projecao8);
	}
	public String getProjecao9() {
		return projecao9.get();
	}
	public void setProjecao9(String projecao9) {
		this.projecao9.set(projecao9);
	}
	public String getProjecao10() {
		return projecao10.get();
	}
	public void setProjecao10(String projecao10) {
		this.projecao10.set(projecao10);
	}
	public String getProjecao11() {
		return projecao11.get();
	}
	public void setProjecao11(String projecao11) {
		this.projecao11.set(projecao11);
	}
	public String getProjecao12() {
		return projecao12.get();
	}
	public void setProjecao12(String projecao12) {
		this.projecao12.set(projecao12);
	}
	public String getProjecao13() {
		return projecao13.get();
	}
	public void setProjecao13(String projecao13) {
		this.projecao13.set(projecao13);
	}
	public String getProjecao14() {
		return projecao14.get();
	}
	public void setProjecao14(String projecao14) {
		this.projecao14.set(projecao14);
	}
	public String getProjecao15() {
		return projecao15.get();
	}
	public void setProjecao15(String projecao15) {
		this.projecao15.set(projecao15);
	}

	public String getProjecaoCustom() {
		return projecaoCustom.get();
	}

	public void setProjecaoCustom(String projecaoCustom) {
		this.projecaoCustom.set(projecaoCustom);
	}
}
