package model;

public class Resumo {
	private int rebuys = 0;
	private double totalGasto = 0;
	private double totalGanho = 0;
	private double saldo = 0;

	public int getRebuys() {
		return rebuys;
	}
	public void setRebuys(int rebuys) {
		this.rebuys = rebuys;
	}
	public double getTotalGasto() {
		return totalGasto;
	}
	public void setTotalGasto(double totalGasto) {
		this.totalGasto = totalGasto;
	}
	public double getTotalGanho() {
		return totalGanho;
	}
	public void setTotalGanho(double totalGanho) {
		this.totalGanho = totalGanho;
	}
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

}
