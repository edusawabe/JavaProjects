package application;

import java.util.LinkedList;

import model.Player;

public class RankingManager {
	private LinkedList<Player> listPlayers;

	private double premiacaoFinalTotal;
	private double premiacaoFinal1;
	private double premiacaoFinal2;
	private double premiacaoFinal3;

	public void updateRanking() {

	}

	public void updateRanking(int mes){

	}
}
